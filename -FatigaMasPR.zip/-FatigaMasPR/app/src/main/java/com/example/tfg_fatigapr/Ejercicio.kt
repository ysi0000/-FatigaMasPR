package com.example.tfg_fatigapr

data class Ejercicio(
    val id:String,
    val peso:Int,
    val RPE:Int,
    val reps:Int
)

