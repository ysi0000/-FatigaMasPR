package com.example.tfg_fatigapr


data class Usuario (
    val id:String,
    val nombre:String,
    val peso:Int,
    val dia:List<Dia>

)

